﻿using System;
using System.Runtime.InteropServices;

namespace E1
{
    internal class Balanca
    {

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int ObterModeloBalanca();
        //[DllImport("E1_Balanca01.dll")] public static extern string ObterModeloBalanca();

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int ConfigurarModeloBalanca(int modeloBalanca);

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int ObterProtocoloComunicacao();

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int ConfigurarProtocoloComunicacao(int protocoloComunicacao);

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int AbrirSerial(string device, int baudrate, int length, char parity, int stopbits);

        //[DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        // public static extern string LerPeso(int qtdLeituras);

        //public static extern int LerPeso(int qtdLeituras);

        [DllImport("E1_Balanca01.dll", EntryPoint = "LerPeso", CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr LerPeso(int qtdLeituras);

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int Fechar();

        [DllImport("E1_Balanca01.dll", EntryPoint = "LerPreco", CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr LerPreco(int qtdLeituras);

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern string LerTara();

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern string LerTotal(double preco);

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int TararBalanca();

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int ZerarBalanca();

        [DllImport("E1_Balanca01.dll", CharSet = CharSet.None, ExactSpelling = false)]
        public static extern int LigarDesligarDisplay();
    }
}
