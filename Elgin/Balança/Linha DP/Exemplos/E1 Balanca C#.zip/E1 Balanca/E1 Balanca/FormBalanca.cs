﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace E1_Balanca
{
    public partial class FormBalanca : Form
    {
        public FormBalanca()
        {
            InitializeComponent();
        }

        private void FormBalanca_Load(object sender, EventArgs e)
        {

        }

        private void btnConfModelo_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbConfModelo.SelectedIndex < 0)
                {
                    MessageBox.Show("Informe o Modelo");
                    cmbConfModelo.Focus();
                    return;
                }

                //int tipoModelo = cmbConfModelo.SelectedIndex + 1;
                int var = cmbConfModelo.SelectedIndex;
                int retorno = E1.Balanca.ConfigurarModeloBalanca(var);

                tbRetorno.Clear();
                tbRetorno.Text = ("Modelo configurado com sucesso");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }

        private void btnObterModeloBalanca_Click(object sender, EventArgs e)
        {
            int retorno;
            retorno = E1.Balanca.ObterModeloBalanca();
            //MessageBox.Show("Retorno " + retorno);
            if (retorno == 0)
            {
                tbRetorno.Text = Convert.ToString("Balança DP 1502 ou DP 3005");
            }
            else if (retorno == 1)
            {
                tbRetorno.Text = Convert.ToString("Balança SA 110");
            }
            else if (retorno == 2)
            {
                tbRetorno.Text = Convert.ToString("Balança DPSC");
            }
            else if (retorno == 3)
            {
                tbRetorno.Text = Convert.ToString("Balança DP30CK");
            }  
            else
            {
                tbRetorno.Text = Convert.ToString("Modelo incompativel. Retorno " + retorno);
            }
            
        }

        private void btnConfProt_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbConfProtocolo.SelectedIndex < 0)
                {
                    MessageBox.Show("Informe o Protocolo");
                    cmbConfModelo.Focus();
                    return;
                }

                int tipoProtocolo = cmbConfProtocolo.SelectedIndex + 1;
                //int numParcelas = Convert.ToInt32(tbQtdParc.Text);
                int retorno = E1.Balanca.ConfigurarProtocoloComunicacao(cmbConfProtocolo.SelectedIndex);

                tbRetorno.Clear();
                tbRetorno.Text = ("Protocolo configurado com sucesso");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }

        private void btnObterProt_Click(object sender, EventArgs e)
        {
            int retorno;
            retorno = E1.Balanca.ObterProtocoloComunicacao();
            //MessageBox.Show("Retorno " + retorno);
            tbRetorno.Text = Convert.ToString("Protocolo de comunicação N° " + retorno);
        }

        private void btnAbrirSerial_Click(object sender, EventArgs e)
        {
            int retorno;
            retorno = E1.Balanca.AbrirSerial(Convert.ToString(tbPorta.Text), Convert.ToInt32(cmbBaudrate.Text), Convert.ToInt32(cmbLength.Text), Convert.ToChar(cmbParity.Text), Convert.ToInt32(cmbStopbits.Text));
            //MessageBox.Show("Retorno " + retorno);
            if (retorno == 0)
            {
                //tbRetorno.Text = Convert.ToString(retorno);
                tbRetorno.Text = ("Conexão aberta com sucesso! Retorno " + retorno);
            }
            else
            {
                tbRetorno.Text = ("Erro ao abrir serial. Retorno " + retorno);
            }
        }

        private void btnFecharConex_Click(object sender, EventArgs e)
        {
            int retorno;
            retorno = E1.Balanca.Fechar();
            //MessageBox.Show("Retorno " + retorno);
            if (retorno == 0)
            {
                tbRetorno.Text = Convert.ToString("Conexão fechada com sucesso");
            }
            else
            {
                tbRetorno.Text = Convert.ToString("Falha ao fechar conexão! Retorno " + retorno);
            }
        }

        private void btnLerTara_Click(object sender, EventArgs e)
        {
            string retorno;
            retorno = E1.Balanca.LerTara();
            tbRetorno.Text = Convert.ToString("Tara: " + retorno);
            //MessageBox.Show("Retorno " + retorno);
        }

        private void btnTararBalanca_Click(object sender, EventArgs e)
        {
            int retorno;
            retorno = E1.Balanca.TararBalanca();
            if(retorno == 0)
            {
                tbRetorno.Text = Convert.ToString("Comando executado com sucesso! Retorno " + retorno);
            }
            else
            {
                tbRetorno.Text = Convert.ToString("Erro ao executar comando! Retorno " + retorno);
            }
            
        }

        private void btnZerarBalanca_Click(object sender, EventArgs e)
        {
            int retorno;
            retorno = E1.Balanca.ZerarBalanca();

            if (retorno == 0)
            {
                tbRetorno.Text = Convert.ToString("Comando executado com sucesso! Retorno " + retorno);
            }
            else
            {
                tbRetorno.Text = Convert.ToString("Erro ao executar comando! Retorno " + retorno);
            }
        }

        private void btnLerPeso_Click(object sender, EventArgs e)
        {

            string retorno;
            retorno = Marshal.PtrToStringAnsi(E1.Balanca.LerPeso(Convert.ToInt32(tbLerPeso.Text)));
            tbRetorno.Text = Convert.ToString("KG: " + retorno);

            //MessageBox.Show("Retorno " + retorno);
            //string retorno;
            //retorno = E1.Balanca.LerPeso(1);
            //string aux = Marshal.PtrToStringAnsi(E1.Balanca.LerPeso(3));
            //tbRetorno.Text = ("KG: " + retorno);
            //MessageBox.Show("Retorno " + retorno);
        }

        private void btnLerPreco_Click(object sender, EventArgs e)
        {
            string retorno;
            retorno = Marshal.PtrToStringAnsi(E1.Balanca.LerPreco(Convert.ToInt32(tbLerPreco.Text)));
            tbRetorno.Text = ("R$ " + retorno);
            //MessageBox.Show("Retorno " + retorno);
        }

        private void btnLerTotal_Click(object sender, EventArgs e)
        {
            string retorno;
            retorno = E1.Balanca.LerTotal(Convert.ToDouble(tbPrecoTotal.Text));
            tbRetorno.Text = Convert.ToString("Total: " + retorno);
            //MessageBox.Show("Retorno " + retorno);
        }

        private void btnLigDisplay_Click(object sender, EventArgs e)
        {
            int retorno;
            retorno = E1.Balanca.LigarDesligarDisplay();
            if (retorno == 0)
            {
                tbRetorno.Text = Convert.ToString("Comando executado com sucesso! Retorno " + retorno);
            }
            else
            {
                tbRetorno.Text = Convert.ToString("Erro ao executar comando! Retorno " + retorno);
            }
        }
    }
}
