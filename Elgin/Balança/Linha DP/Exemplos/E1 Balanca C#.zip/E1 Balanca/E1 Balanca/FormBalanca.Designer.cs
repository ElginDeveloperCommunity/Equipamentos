﻿namespace E1_Balanca
{
    partial class FormBalanca
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbPrecoTotal = new System.Windows.Forms.TextBox();
            this.tbLerPreco = new System.Windows.Forms.TextBox();
            this.tbLerPeso = new System.Windows.Forms.TextBox();
            this.btnLigDisplay = new System.Windows.Forms.Button();
            this.btnZerarBalanca = new System.Windows.Forms.Button();
            this.btnTararBalanca = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbStopbits = new System.Windows.Forms.ComboBox();
            this.cmbParity = new System.Windows.Forms.ComboBox();
            this.cmbLength = new System.Windows.Forms.ComboBox();
            this.cmbBaudrate = new System.Windows.Forms.ComboBox();
            this.tbPorta = new System.Windows.Forms.TextBox();
            this.cmbConfProtocolo = new System.Windows.Forms.ComboBox();
            this.cmbConfModelo = new System.Windows.Forms.ComboBox();
            this.tbRetorno = new System.Windows.Forms.TextBox();
            this.btnLerTotal = new System.Windows.Forms.Button();
            this.btnLerTara = new System.Windows.Forms.Button();
            this.btnLerPreco = new System.Windows.Forms.Button();
            this.btnFecharConex = new System.Windows.Forms.Button();
            this.btnAbrirSerial = new System.Windows.Forms.Button();
            this.btnLerPeso = new System.Windows.Forms.Button();
            this.btnConfProt = new System.Windows.Forms.Button();
            this.btnObterProt = new System.Windows.Forms.Button();
            this.btnConfModelo = new System.Windows.Forms.Button();
            this.btnObterModeloBalanca = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(273, 421);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 69;
            this.label10.Text = "Preço";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(273, 380);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 13);
            this.label9.TabIndex = 68;
            this.label9.Text = "Qtd Leitura";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(273, 338);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 67;
            this.label8.Text = "Qtd Leitura";
            // 
            // tbPrecoTotal
            // 
            this.tbPrecoTotal.Location = new System.Drawing.Point(276, 436);
            this.tbPrecoTotal.Name = "tbPrecoTotal";
            this.tbPrecoTotal.Size = new System.Drawing.Size(44, 20);
            this.tbPrecoTotal.TabIndex = 66;
            this.tbPrecoTotal.Text = "10,99";
            // 
            // tbLerPreco
            // 
            this.tbLerPreco.Location = new System.Drawing.Point(276, 395);
            this.tbLerPreco.Name = "tbLerPreco";
            this.tbLerPreco.Size = new System.Drawing.Size(44, 20);
            this.tbLerPreco.TabIndex = 65;
            this.tbLerPreco.Text = "2";
            // 
            // tbLerPeso
            // 
            this.tbLerPeso.Location = new System.Drawing.Point(276, 354);
            this.tbLerPeso.Name = "tbLerPeso";
            this.tbLerPeso.Size = new System.Drawing.Size(44, 20);
            this.tbLerPeso.TabIndex = 64;
            this.tbLerPeso.Text = "2";
            // 
            // btnLigDisplay
            // 
            this.btnLigDisplay.Location = new System.Drawing.Point(355, 421);
            this.btnLigDisplay.Name = "btnLigDisplay";
            this.btnLigDisplay.Size = new System.Drawing.Size(81, 35);
            this.btnLigDisplay.TabIndex = 63;
            this.btnLigDisplay.Text = "Lig/Desl Display";
            this.btnLigDisplay.UseVisualStyleBackColor = true;
            this.btnLigDisplay.Click += new System.EventHandler(this.btnLigDisplay_Click);
            // 
            // btnZerarBalanca
            // 
            this.btnZerarBalanca.Location = new System.Drawing.Point(34, 421);
            this.btnZerarBalanca.Name = "btnZerarBalanca";
            this.btnZerarBalanca.Size = new System.Drawing.Size(81, 35);
            this.btnZerarBalanca.TabIndex = 62;
            this.btnZerarBalanca.Text = "Zerar Balança";
            this.btnZerarBalanca.UseVisualStyleBackColor = true;
            this.btnZerarBalanca.Click += new System.EventHandler(this.btnZerarBalanca_Click);
            // 
            // btnTararBalanca
            // 
            this.btnTararBalanca.Location = new System.Drawing.Point(34, 380);
            this.btnTararBalanca.Name = "btnTararBalanca";
            this.btnTararBalanca.Size = new System.Drawing.Size(81, 35);
            this.btnTararBalanca.TabIndex = 61;
            this.btnTararBalanca.Text = "Tarar Balança";
            this.btnTararBalanca.UseVisualStyleBackColor = true;
            this.btnTararBalanca.Click += new System.EventHandler(this.btnTararBalanca_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(28, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 16);
            this.label7.TabIndex = 60;
            this.label7.Text = "Configuração Inicial";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(28, 316);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 16);
            this.label6.TabIndex = 59;
            this.label6.Text = "Outras Funções";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(318, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 58;
            this.label5.Text = "Stopbits";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(270, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 57;
            this.label4.Text = "Parity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(225, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 56;
            this.label3.Text = "Length";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(166, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 55;
            this.label2.Text = "Baudrate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(118, 222);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 54;
            this.label1.Text = "Porta";
            // 
            // cmbStopbits
            // 
            this.cmbStopbits.FormattingEnabled = true;
            this.cmbStopbits.Items.AddRange(new object[] {
            "1",
            "2"});
            this.cmbStopbits.Location = new System.Drawing.Point(321, 236);
            this.cmbStopbits.Name = "cmbStopbits";
            this.cmbStopbits.Size = new System.Drawing.Size(33, 21);
            this.cmbStopbits.TabIndex = 53;
            this.cmbStopbits.Text = "1";
            // 
            // cmbParity
            // 
            this.cmbParity.FormattingEnabled = true;
            this.cmbParity.Items.AddRange(new object[] {
            "n",
            "N",
            "e",
            "E",
            "o",
            "O"});
            this.cmbParity.Location = new System.Drawing.Point(273, 237);
            this.cmbParity.Name = "cmbParity";
            this.cmbParity.Size = new System.Drawing.Size(35, 21);
            this.cmbParity.TabIndex = 52;
            this.cmbParity.Text = "N";
            // 
            // cmbLength
            // 
            this.cmbLength.FormattingEnabled = true;
            this.cmbLength.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.cmbLength.Location = new System.Drawing.Point(228, 237);
            this.cmbLength.Name = "cmbLength";
            this.cmbLength.Size = new System.Drawing.Size(33, 21);
            this.cmbLength.TabIndex = 51;
            this.cmbLength.Text = "8";
            // 
            // cmbBaudrate
            // 
            this.cmbBaudrate.FormattingEnabled = true;
            this.cmbBaudrate.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.cmbBaudrate.Location = new System.Drawing.Point(169, 237);
            this.cmbBaudrate.Name = "cmbBaudrate";
            this.cmbBaudrate.Size = new System.Drawing.Size(48, 21);
            this.cmbBaudrate.TabIndex = 50;
            this.cmbBaudrate.Text = "9600";
            // 
            // tbPorta
            // 
            this.tbPorta.Location = new System.Drawing.Point(118, 237);
            this.tbPorta.Name = "tbPorta";
            this.tbPorta.Size = new System.Drawing.Size(44, 20);
            this.tbPorta.TabIndex = 49;
            this.tbPorta.Text = "COM11";
            // 
            // cmbConfProtocolo
            // 
            this.cmbConfProtocolo.FormattingEnabled = true;
            this.cmbConfProtocolo.Items.AddRange(new object[] {
            "0-Protocolo 0",
            "1-Protocolo 1",
            "2-Protocolo 2",
            "3-Protocolo 3",
            "4-Protocolo 4",
            "5-Protocolo 5",
            "6-Protocolo 6",
            "7-Protocolo 7"});
            this.cmbConfProtocolo.Location = new System.Drawing.Point(118, 151);
            this.cmbConfProtocolo.Name = "cmbConfProtocolo";
            this.cmbConfProtocolo.Size = new System.Drawing.Size(143, 21);
            this.cmbConfProtocolo.TabIndex = 48;
            this.cmbConfProtocolo.Text = "Selecione Protocolo";
            // 
            // cmbConfModelo
            // 
            this.cmbConfModelo.FormattingEnabled = true;
            this.cmbConfModelo.Items.AddRange(new object[] {
            "0 - DP-3005/DP-1502",
            "1 - SA-110",
            "2 - DPSC",
            "3 - DP30CK"});
            this.cmbConfModelo.Location = new System.Drawing.Point(118, 69);
            this.cmbConfModelo.Name = "cmbConfModelo";
            this.cmbConfModelo.Size = new System.Drawing.Size(143, 21);
            this.cmbConfModelo.TabIndex = 47;
            this.cmbConfModelo.Text = "Selecione Modelo";
            // 
            // tbRetorno
            // 
            this.tbRetorno.BackColor = System.Drawing.Color.White;
            this.tbRetorno.Location = new System.Drawing.Point(273, 55);
            this.tbRetorno.Multiline = true;
            this.tbRetorno.Name = "tbRetorno";
            this.tbRetorno.Size = new System.Drawing.Size(163, 141);
            this.tbRetorno.TabIndex = 46;
            // 
            // btnLerTotal
            // 
            this.btnLerTotal.Location = new System.Drawing.Point(184, 421);
            this.btnLerTotal.Name = "btnLerTotal";
            this.btnLerTotal.Size = new System.Drawing.Size(81, 35);
            this.btnLerTotal.TabIndex = 45;
            this.btnLerTotal.Text = "Ler Total";
            this.btnLerTotal.UseVisualStyleBackColor = true;
            this.btnLerTotal.Click += new System.EventHandler(this.btnLerTotal_Click);
            // 
            // btnLerTara
            // 
            this.btnLerTara.Location = new System.Drawing.Point(34, 339);
            this.btnLerTara.Name = "btnLerTara";
            this.btnLerTara.Size = new System.Drawing.Size(81, 35);
            this.btnLerTara.TabIndex = 44;
            this.btnLerTara.Text = "Ler Tara";
            this.btnLerTara.UseVisualStyleBackColor = true;
            this.btnLerTara.Click += new System.EventHandler(this.btnLerTara_Click);
            // 
            // btnLerPreco
            // 
            this.btnLerPreco.Location = new System.Drawing.Point(184, 380);
            this.btnLerPreco.Name = "btnLerPreco";
            this.btnLerPreco.Size = new System.Drawing.Size(81, 35);
            this.btnLerPreco.TabIndex = 43;
            this.btnLerPreco.Text = "Ler Preço";
            this.btnLerPreco.UseVisualStyleBackColor = true;
            this.btnLerPreco.Click += new System.EventHandler(this.btnLerPreco_Click);
            // 
            // btnFecharConex
            // 
            this.btnFecharConex.BackColor = System.Drawing.Color.Crimson;
            this.btnFecharConex.ForeColor = System.Drawing.Color.White;
            this.btnFecharConex.Location = new System.Drawing.Point(31, 267);
            this.btnFecharConex.Name = "btnFecharConex";
            this.btnFecharConex.Size = new System.Drawing.Size(81, 35);
            this.btnFecharConex.TabIndex = 42;
            this.btnFecharConex.Text = "Fechar Conexao";
            this.btnFecharConex.UseVisualStyleBackColor = false;
            this.btnFecharConex.Click += new System.EventHandler(this.btnFecharConex_Click);
            // 
            // btnAbrirSerial
            // 
            this.btnAbrirSerial.BackColor = System.Drawing.Color.LawnGreen;
            this.btnAbrirSerial.Location = new System.Drawing.Point(31, 222);
            this.btnAbrirSerial.Name = "btnAbrirSerial";
            this.btnAbrirSerial.Size = new System.Drawing.Size(81, 36);
            this.btnAbrirSerial.TabIndex = 41;
            this.btnAbrirSerial.Text = "Abrir Serial";
            this.btnAbrirSerial.UseVisualStyleBackColor = false;
            this.btnAbrirSerial.Click += new System.EventHandler(this.btnAbrirSerial_Click);
            // 
            // btnLerPeso
            // 
            this.btnLerPeso.Location = new System.Drawing.Point(184, 339);
            this.btnLerPeso.Name = "btnLerPeso";
            this.btnLerPeso.Size = new System.Drawing.Size(81, 35);
            this.btnLerPeso.TabIndex = 40;
            this.btnLerPeso.Text = "Ler Peso";
            this.btnLerPeso.UseVisualStyleBackColor = true;
            this.btnLerPeso.Click += new System.EventHandler(this.btnLerPeso_Click);
            // 
            // btnConfProt
            // 
            this.btnConfProt.Location = new System.Drawing.Point(31, 137);
            this.btnConfProt.Name = "btnConfProt";
            this.btnConfProt.Size = new System.Drawing.Size(81, 35);
            this.btnConfProt.TabIndex = 39;
            this.btnConfProt.Text = "Conf Protocolo";
            this.btnConfProt.UseVisualStyleBackColor = true;
            this.btnConfProt.Click += new System.EventHandler(this.btnConfProt_Click);
            // 
            // btnObterProt
            // 
            this.btnObterProt.Location = new System.Drawing.Point(31, 178);
            this.btnObterProt.Name = "btnObterProt";
            this.btnObterProt.Size = new System.Drawing.Size(81, 35);
            this.btnObterProt.TabIndex = 38;
            this.btnObterProt.Text = "Obter Protocolo";
            this.btnObterProt.UseVisualStyleBackColor = true;
            this.btnObterProt.Click += new System.EventHandler(this.btnObterProt_Click);
            // 
            // btnConfModelo
            // 
            this.btnConfModelo.Location = new System.Drawing.Point(31, 55);
            this.btnConfModelo.Name = "btnConfModelo";
            this.btnConfModelo.Size = new System.Drawing.Size(81, 35);
            this.btnConfModelo.TabIndex = 37;
            this.btnConfModelo.Text = "Conf Modelo";
            this.btnConfModelo.UseVisualStyleBackColor = true;
            this.btnConfModelo.Click += new System.EventHandler(this.btnConfModelo_Click);
            // 
            // btnObterModeloBalanca
            // 
            this.btnObterModeloBalanca.Location = new System.Drawing.Point(31, 96);
            this.btnObterModeloBalanca.Name = "btnObterModeloBalanca";
            this.btnObterModeloBalanca.Size = new System.Drawing.Size(81, 35);
            this.btnObterModeloBalanca.TabIndex = 36;
            this.btnObterModeloBalanca.Text = "Obter Modelo";
            this.btnObterModeloBalanca.UseVisualStyleBackColor = true;
            this.btnObterModeloBalanca.Click += new System.EventHandler(this.btnObterModeloBalanca_Click);
            // 
            // FormBalanca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(484, 479);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tbPrecoTotal);
            this.Controls.Add(this.tbLerPreco);
            this.Controls.Add(this.tbLerPeso);
            this.Controls.Add(this.btnLigDisplay);
            this.Controls.Add(this.btnZerarBalanca);
            this.Controls.Add(this.btnTararBalanca);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbStopbits);
            this.Controls.Add(this.cmbParity);
            this.Controls.Add(this.cmbLength);
            this.Controls.Add(this.cmbBaudrate);
            this.Controls.Add(this.tbPorta);
            this.Controls.Add(this.cmbConfProtocolo);
            this.Controls.Add(this.cmbConfModelo);
            this.Controls.Add(this.tbRetorno);
            this.Controls.Add(this.btnLerTotal);
            this.Controls.Add(this.btnLerTara);
            this.Controls.Add(this.btnLerPreco);
            this.Controls.Add(this.btnFecharConex);
            this.Controls.Add(this.btnAbrirSerial);
            this.Controls.Add(this.btnLerPeso);
            this.Controls.Add(this.btnConfProt);
            this.Controls.Add(this.btnObterProt);
            this.Controls.Add(this.btnConfModelo);
            this.Controls.Add(this.btnObterModeloBalanca);
            this.Name = "FormBalanca";
            this.Text = "E1_Balanca";
            this.Load += new System.EventHandler(this.FormBalanca_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbPrecoTotal;
        private System.Windows.Forms.TextBox tbLerPreco;
        private System.Windows.Forms.TextBox tbLerPeso;
        private System.Windows.Forms.Button btnLigDisplay;
        private System.Windows.Forms.Button btnZerarBalanca;
        private System.Windows.Forms.Button btnTararBalanca;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbStopbits;
        private System.Windows.Forms.ComboBox cmbParity;
        private System.Windows.Forms.ComboBox cmbLength;
        private System.Windows.Forms.ComboBox cmbBaudrate;
        private System.Windows.Forms.TextBox tbPorta;
        private System.Windows.Forms.ComboBox cmbConfProtocolo;
        private System.Windows.Forms.ComboBox cmbConfModelo;
        private System.Windows.Forms.TextBox tbRetorno;
        private System.Windows.Forms.Button btnLerTotal;
        private System.Windows.Forms.Button btnLerTara;
        private System.Windows.Forms.Button btnLerPreco;
        private System.Windows.Forms.Button btnFecharConex;
        private System.Windows.Forms.Button btnAbrirSerial;
        private System.Windows.Forms.Button btnLerPeso;
        private System.Windows.Forms.Button btnConfProt;
        private System.Windows.Forms.Button btnObterProt;
        private System.Windows.Forms.Button btnConfModelo;
        private System.Windows.Forms.Button btnObterModeloBalanca;
    }
}

